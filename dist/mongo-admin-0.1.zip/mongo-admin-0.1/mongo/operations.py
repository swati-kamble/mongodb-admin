# Copyright (C) 2012 Costia Adrian, certSIGN
# Created on Mar 5, 2012
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from mongo.admin.dbadm import *
from mongo.admin.replication import Replication
from mongo.admin.mongodb import MongoDB,ConfigServer,MongoRouter
from mongo.admin.resplicaset import ReplicaSet
from mongo.admin.sharding import Shard
from mongo.admin.mgridfs import *

class Mongo:

    @staticmethod        
    def start(self,**args):
        mongo_db = MongoDB(**args)
        mongo_db.setParamaters()
        mongo_db.start()

    @staticmethod
    def stop(self):
        mongo_db = MongoDB()
        mongo_db.stop()

    @staticmethod
    def resume(self):
        mongo_db = MongoDB()
        mongo_db.resume()

    @staticmethod
    def suspend(self):
        mongo_db = MongoDB()
        mongo_db.suspend()
    
    @staticmethod
    def serverInfo(**args):
        mongo_db = MongoDB(**args)
        return mongo_db.serverInfo()

    @staticmethod
    def serverLog(**args):
        mongo_db = MongoDB(**args)
        return mongo_db.viewServerLog()

    @staticmethod
    def viewOperations(**args):
        mongo_db = MongoDB(**args)
        return mongo_db.viewOperations()

    @staticmethod
    def repair(database,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.repair(database)

    @staticmethod
    def compactCollection(collection,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.compactCollection(collection)
    
    @staticmethod
    def checkDataIntegrity(collection,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.checkIntegrity(collection)
    
    @staticmethod
    def startMaster(db_path,**args):
        master = Replication(is_master=True,**args)
        master.dbPath(db_path)
        master.initParamaters()
        master.start()
        
    @staticmethod
    def startSlave(db_path,master,**args):
        '''
            Mandatory parameter: master address
            Example:
                mongo = Mongo()
                mongo.startSlave("192.168.2.100:27020")
                
        '''
        slave = Replication(is_master=False,**args)
        slave.dbPath(db_path)
        slave.source(master)
        slave.initParamaters()
        slave.start()
    
    @staticmethod
    def masterStatus(**args):
        master = Replication(is_master=True,**args)
        return master.masterInfo()

    @staticmethod
    def slaveStatus(**args):
        slave = Replication(is_master=False,**args)
        return slave.slaveInfo()
    
    @staticmethod
    def startReplicaSet(name,db_path,**args):
        '''
           Example:
           
           mongo = Mongo()
           mongo.startReplicaSet(name="csign",db_path="/data/db/replica/r1/",bind_ip="172.16.101.229",port=27020)
           mongo.start()
        '''
        replSet = ReplicaSet(demonize=False,**args)
        replSet.setName(name)
        replSet.dbPath(db_path)        
        replSet.initParamaters()
        replSet.start()
    
    @staticmethod
    def initiateReplicaSet(config,**args):
        replSet = ReplicaSet(config=config,**args)
        replSet.initiate()
    
    @staticmethod
    def statusReplicaSet(**args):
        replSet = ReplicaSet(**args)
        return replSet.getStatus()
    
    @staticmethod
    def isMaster(**args):
        replSet = ReplicaSet(**args)
        return replSet.isMaster()
        
    @staticmethod
    def addNode(host,**args):
        '''
            Add new node 
        '''
        replSet = ReplicaSet(**args)
        return replSet.addNode(host)
    
    @staticmethod
    def listNodes(**args):
        replSet = ReplicaSet(**args)
        return replSet.listNodes()

    @staticmethod
    def startConfigServer(db_path,**args):
        '''
            Example:
            
            mongo = Mongo()
            mongo.startConfigServer(db_path="/data/db/replica/r1/",bind_ip="172.16.101.229",port=20000)
            
            This will produce:
                /usr/bin/mongod --configsvr --dbpath=/data/db/config/ --port 20000 --bind_ip=172.16.101.229
            
        '''
        config_srv = ConfigServer(db_path,**args)
        config_srv.start()
    
    @staticmethod
    def startRouter(servers,**args):
        '''
            Example:
            mongo = Mongo()
            mongo.startRouter(servers="172.16.101.229:27020",port=27021,bind_ip="172.16.101.229")
            
        '''
        mongo_router = MongoRouter(servers=servers,**args)
        mongo_router.start()


    @staticmethod
    def statusRouter(**args):
        '''
            Get router (mongos) status
        '''
        mongo_router = MongoRouter(**args)
        return mongo_router.getStatus()

    @staticmethod
    def startShard(db_path,use_replica=False,servers=None,**args):
        '''
            Example:
            
                1. Simple shard
                    mongo = Mongo()
                    mongo.startShard(db_path="/data/db/shard/s1/",bind_ip="172.16.101.229",port=20001)
                    
                2. With replica set enabled
                    mongo = Mongo()
                    mongo.startShard(
                        db_path="/data/db/shard/s1/",
                        use_replica=True,
                        servers="csing/alpha:27021,beta:27021",
                        bind_ip="172.16.101.229",
                        port=20001
                    )
            
        '''        
        shard = Shard(db_path=db_path,**args)
        if use_replica and servers is not None:
            shard.useReplicaSet(servers)
        shard.initParamaters()
        shard.start()
    
    @staticmethod
    def addShardNode(servers,**args):
        shard = Shard(**args)
        return shard.addNode(servers)

    @staticmethod
    def shardDB(db,**args):
        shard = Shard(**args)
        return shard.shardDb(db)

    @staticmethod
    def shardCollection(collection,key,**args):
        shard = Shard(**args)
        return shard.shardCollection(collection,key)
    
    @staticmethod
    def listShards(**args):
        shard = Shard(**args)
        return shard.list()

    @staticmethod
    def statusShards(**args):
        shard = Shard(**args)
        return shard.getStatus()

    @staticmethod
    def moveTo(db,to_shard,**args):
        shard = Shard(**args)
        return shard.moveToPrimary(db, to_shard)

    @staticmethod
    def copyTo(from_db,to_db,from_host,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.copyTo(from_db,to_db,from_host)

    @staticmethod
    def addUser(db,user,pwd):
        admin = DbAdmin()
        admin.addUser(user,pwd,db)
        
    @staticmethod
    def delUser(db,user):
        admin = DbAdmin()
        admin.delUser(user,db)

    @staticmethod
    def listDb(**args):
        mongo_db = MongoDB(**args)
        return mongo_db.listDatabases()
    
    @staticmethod
    def dropDb(db,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.dropDb(db)

    @staticmethod
    def addIndex(collection,idx_name,idx_key,unique,drop_duplicates,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.addIndex(collection,idx_name,idx_key,unique,drop_duplicates)

    @staticmethod
    def dropIndex(collection,idx_name,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.dropIndex(collection, idx_name)
                             
    @staticmethod
    def getIndexes(database,**args):
        mongo_db = MongoDB(**args)
        return mongo_db.listIndexes(database)
    

        